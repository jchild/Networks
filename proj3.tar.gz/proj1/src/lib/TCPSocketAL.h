/**
 * ANDES Lab - University of California, Merced
 * This class provides the basic functions of a network node.
 *
 * @author UCM ANDES Lab
 * @date   October 1 2012
 * 
 */ 
 #include "../packet.h"
#include "Buff.h"
#ifndef TCP_SOCKET_AL_H
#define TCP_SOCKET_AL_H

enum TCPSOCKET_STATE{
	CLOSED=0,
	LISTEN=1,
	SYN_SENT=2,
	SYN_RCVD=3,
	ESTABLISHED=4,
	SHUTDOWN=5,
	CLOSING=6
};

enum TCPSOCKET_ERR_MSG{
 
	TCP_ERRMSG_SUCCESS 
 
};

typedef struct TCPSocketAL{
	/*Insert Variables Here */
	enum TCPSOCKET_STATE state;
	uint8_t localPort;
	uint8_t destPort;
	uint16_t address;
	uint16_t destAddr;
	bool free;
	bool closes;
	bool isServer;
	
	Buff sendBuffer;
	Buff recieverBuffer;
	
}TCPSocketAL;

void logSocket(TCPSocketAL *input){
	dbg("TCPDebug", "localPort: %hhu destPort: %hhu address: %hhu destAddr: %hhu free:%hhu\n",
	input->localPort, input->destPort, input->address, input->destAddr, input->free);
}

#endif /* TCP_SOCKET_AL_H */
