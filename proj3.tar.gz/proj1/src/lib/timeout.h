#ifndef TIMEOUT_H
#define TIMEOUT_H
#include "../transport.h"

typedef struct timeout{
	transport pac;
	bool isthere;
	uint32_t time;
	uint16_t address;
}timeout;


#endif /* TIMEOUT_H */
