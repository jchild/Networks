#ifndef BUFF_H
#define BUFF_H


//Author: JON CHILD

#define ARRAYSIZE 30
#define MAXNUMVALS ARRAYSIZE

typedef struct Buff
{	
	uint8_t values[ARRAYSIZE]; //Buff of values
	uint8_t numValues;			//number of objects currently in the array
}Buff;

void BuffInit(Buff *cur){
	cur->numValues = 0;	
}

bool BuffPushBack(Buff* cur, uint8_t newVal){
	if(cur->numValues != MAXNUMVALS){
		cur->values[cur->numValues] = newVal;
		++cur->numValues;
		return TRUE;	
	}else return FALSE;
}

bool BuffPushFront(Buff* cur, uint8_t newVal){
	if(cur->numValues!= MAXNUMVALS){
		uint8_t i;
		for( i = cur->numValues-1; i >= 0; --i){
			cur->values[i+1] = cur->values[i];
		}
		cur->values[0] = newVal;
		++cur->numValues;
		return TRUE;	
	}else	return FALSE;
} 

uint8_t pop_backBuff(Buff* cur){
	--cur->numValues;
	return cur->values[cur->numValues];
}

uint8_t pop_frontBuff(Buff* cur){
	nx_uint8_t returnVal;
	nx_uint8_t i;	
	returnVal = cur->values[0];
	for(i = 1; i < cur->numValues; ++i)
	{
		cur->values[i-1] = cur->values[i];
	}
	--cur->numValues;
	return returnVal;			
}

uint8_t frontBuff(Buff* cur)
{
	return cur->values[0];
}

uint8_t backBuff(Buff * cur)
{
	return cur->values[cur->numValues-1];	
}

bool BuffIsEmpty(Buff* cur)
{
	if(cur->numValues == 0)
		return TRUE;
	else
		return FALSE;
}

uint8_t BuffSize(Buff* cur){	return cur->numValues;}

void BuffClear(Buff* cur){	cur->numValues = 0;}

uint8_t BuffGet(Buff* cur, nx_uint8_t i){	return cur->values[i];}


#endif /* Buff_H */
